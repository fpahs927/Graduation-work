﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Diagnostics;
using System.Threading;
using System.IO;
using System.IO.Compression;
using System.Management;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections;
using StringTok;

namespace Viewer
{
    public partial class Viewer : Form
    {
        private const int SEND_ID = 100;
        private string id = "gest";


        private const int MSG = 200;
        private const int DISCONNECT = 300;
        private const int COUNT_VIEW = 400;

        private IPAddress ip;
        private int chatPort;
        private IPEndPoint chatEndPoint;
        Socket chatSocket;

        private int imagePort;
        private IPEndPoint imageEndPoint;
        Socket imageSocket;

        private int filePort;
        private IPEndPoint fileEndPoint;
        Socket fileSocket;

        Thread th1 = null;
        Thread th2 = null;
        Thread th3 = null;

        private string str;
        private string list;
        private string connect;
        private string userNum;

        private byte[] receiveStr;
        private byte[] receiveData;
        private byte[] receiveFile;

        delegate void TextSetCallback();
        delegate void ListSetCallback();
        delegate void Current_AccessCallback();

        public Viewer()
        {
            InitializeComponent();

            searchImage();
        }

        private void Connect_Image()
        {
            try
            {
                imageSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                imageSocket.Connect(imageEndPoint);

                receiveData = new byte[1000000];
                while (th2.IsAlive)
                {
                    try
                    {
                        imageSocket.Receive(receiveData, receiveData.Length, SocketFlags.None);

                        byte[] ImageData = receiveData;
                        printScreen(ImageData);
                    }
                    catch (Exception e)
                    {
                        continue;
                    }
                }
            }
            catch (Exception e)
            {

            }
        }

        private void printScreen(byte[] data)
        {
            MemoryStream ms = new MemoryStream();
            ms.Write(data, 0, data.Length);
            Bitmap bitmap = new Bitmap(ms);
            bitmap.Save("view.jpg", ImageFormat.Jpeg);

            ScreenView.ImageLocation = "view.jpg";
        }

        private void ViewerSet()
        {
            if (ViewerList.InvokeRequired)
            {
                ListSetCallback callback = new ListSetCallback(ViewerSet);
                Invoke(callback, new object[] { });
            }
            else
            {
                ViewerList.Text = "";
                ViewerList.Text = list;
            }
        }

        private void TypeField_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                e.KeyChar = ' ';
                string str = MSG + "||" + userNum + ">>" + TypeField.Text + "||";
                byte[] strBuffer = Encoding.UTF8.GetBytes(str);
                chatSocket.Send(strBuffer);
                TypeField.Text = "";
            }
        }

        private void Viewer_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                disConnect();
                Thread.Sleep(500);

                chatSocket.Close();
                imageSocket.Close();
                fileSocket.Close();
                th1.Abort();
                th2.Abort();
                th3.Abort();
                this.Close();
            }
            catch (Exception except) { }

        }

        private void disConnect()
        {
            string str = DISCONNECT + "||" + userNum + "||";
            byte[] strBuf = Encoding.UTF8.GetBytes(str);
            chatSocket.Send(strBuf);
        }

        private void Connect_Chat()
        {
            try
            {
                chatSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                chatSocket.Connect(chatEndPoint);

                sendID();

                receiveStr = new byte[256];

                while (th1.IsAlive)
                {
                    try
                    {
                        int length = chatSocket.Receive(receiveStr, receiveStr.Length, SocketFlags.None);
                        str = Encoding.UTF8.GetString(receiveStr, 0, length);
                        StringTokenizer st = new StringTokenizer(str, "||");
                        int text = int.Parse(st.NextToken());

                        switch (text)
                        {
                            case MSG:
                                str = st.NextToken();
                                ChatSet();
                                break;
                            case SEND_ID:
                                list = "=== 현재 참여자 ===";
                                list += st.NextToken();
                                ListSet();
                                break;
                        }
                    }
                    catch (Exception e) { continue; }
                }
            }
            catch (Exception e) { }
        }

        private void ChatSet()
        {
            if (this.ChatField.InvokeRequired)
            {
                TextSetCallback call = new TextSetCallback(ChatSet);
                this.Invoke(call, new object[] { });
            }
            else
            {
                this.ChatField.AppendText(str + Environment.NewLine);
            }
        }

        private void ListSet()
        {
            if (ViewerList.InvokeRequired)
            {
                ListSetCallback d = new ListSetCallback(ListSet);
                Invoke(d, new object[] { });
            }
            else
            {
                ViewerList.Text = "";

                ViewerList.Text = list;
            }
        }

        private void CntButton_Click(object sender, EventArgs e)
        {
            if (CntButton.Text == "연 결")
            {
                WatingPage.Visible = false;
                ScreenView.BackgroundImage = null;
                CntButton.Text = "연결 종료";
                ON.Visible = true;
                OFF.Visible = false;
                TypeField.ReadOnly = false;
                TypeField.Focus();
                SendButton.Enabled = true;

                ip = IPAddress.Parse("127.0.0.1");

                chatPort = 23;
                chatEndPoint = new IPEndPoint(ip, chatPort);
                th1 = new Thread(new ThreadStart(Connect_Chat));
                th1.Start();

                imagePort = 22;
                imageEndPoint = new IPEndPoint(ip, imagePort);
                th2 = new Thread(new ThreadStart(Connect_Image));
                th2.Start();

                filePort = 24;
                fileEndPoint = new IPEndPoint(ip, filePort);
                th3 = new Thread(new ThreadStart(Connect_File));
                th3.Start();
            }
            else
            {
                WatingPage.Visible = true;
                CntButton.Text = "연 결";
                ON.Visible = false;
                OFF.Visible = true;
                TypeField.ReadOnly = true;
                SendButton.Enabled = false;

                disConnect();
                Thread.Sleep(500);

                imageSocket.Close();
                chatSocket.Close();
                fileSocket.Close();
                th1.Abort();
                th2.Abort();
                th3.Abort();
            }
        }

        private void SendButton_Click(object sender, EventArgs e)
        {
            string str = MSG + "||" + TypeField.Text + "||";
            byte[] strBuffer = Encoding.UTF8.GetBytes(str);
            chatSocket.Send(strBuffer);
            TypeField.Text = null;
        }

        private int captureCount = 0;

        private void CapButton_Click(object sender, EventArgs e)
        {
            Image img = ScreenView.Image;
            Image changeImg = new Bitmap(img, 2880, 1620);

            string saveFolder = Directory.GetCurrentDirectory() + "\\captureScreen";
            if (!Directory.Exists(saveFolder))
            {
                Directory.CreateDirectory(saveFolder);
            }
            string fileName = "";

            if (captureCount < 10)
            {
                fileName = "\\capture0" + Convert.ToString(captureCount++) + ".png";
            }
            else
            {
                fileName = "\\capture" + Convert.ToString(captureCount++) + ".png";
            }

            changeImg.Save(saveFolder + fileName, System.Drawing.Imaging.ImageFormat.Png);
        }



        private void sendID()
        {
            string str = SEND_ID + "||" + id + "||";
            byte[] strBuffer = Encoding.UTF8.GetBytes(str);
            chatSocket.Send(strBuffer);    // 필명 전송      
        }

        private void searchImage()
        {
            string[] files = { };
            try
            {
                files = Directory.GetFiles(Directory.GetCurrentDirectory() + "\\captureScreen", "*.png", SearchOption.TopDirectoryOnly);
            }
            catch (IOException e)
            {
                MessageBox.Show(e.Message);
            }

            string s = "";
            for (int i = 0; i < files.Length; i++)
            {
                if (files[i].Contains("capture"))
                    s = files[i];
            }
            if (s != "")
            {
                files = s.Split('\\');
                for (int j = 0; j < files.Length; j++)
                {
                    if (files[j].Contains("capture"))
                        s = files[j];
                }

                string t = s.Substring(7, 2);

                captureCount = int.Parse(t) + 1;
            }
        }
        
        private string saveFileName;
        private int saveFileSize;
        private int fileNameSize;

        private void Connect_File()
        {
            try
            {
                while (th3.IsAlive)
                {
                    fileSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    fileSocket.Connect(fileEndPoint);

                    byte[] buffer = new byte[4];
                    fileSocket.Receive(buffer);
                    saveFileSize = BitConverter.ToInt32(buffer, 0);

                    buffer = new byte[4];
                    fileSocket.Receive(buffer);
                    fileNameSize = BitConverter.ToInt32(buffer, 0);

                    buffer = new byte[fileNameSize];
                    fileSocket.Receive(buffer);
                    saveFileName = Encoding.UTF8.GetString(buffer);

                    buffer = new byte[1024];
                    int fullLength = 0;
                    string saveDir = Directory.GetCurrentDirectory() + "\\" + saveFileName;

                    FileStream fs = new FileStream(saveDir, FileMode.Create, FileAccess.Write);
                    BinaryWriter bw = new BinaryWriter(fs);

                    while (fullLength < saveFileSize)
                    {
                        int receiveLength = fileSocket.Receive(buffer);
                        bw.Write(buffer, 0, receiveLength);
                        fullLength += receiveLength;
                    }
                }

                /*
                receiveFile = new byte[5000000];
                while (th3.IsAlive)
                {
                    try
                    {
                        int length = fileSocket.Receive(receiveFile, receiveFile.Length, SocketFlags.None);
                        fileStr = Encoding.UTF8.GetString(receiveFile, 0, length);
                        StringTokenizer st = new StringTokenizer(fileStr, "||");
                        int text = int.Parse(st.NextToken());
                        int fullLength = 0;

                        switch(text)
                        {
                            case FILE_NAME:
                                saveFileName = st.NextToken();
                                break;
                            case FILE_SIZE:
                                saveFileSize = int.Parse(st.NextToken());
                                break;
                            case FILE_DATA:
                                byte[] file = new byte[saveFileSize];
                                file = Encoding.UTF8.GetBytes(st.NextToken());

                                FileStream fs = new FileStream(saveFileName, FileMode.Create, FileAccess.Write);
                                BinaryWriter writer = new BinaryWriter(fs);
                                while (fullLength < saveFileSize)
                                {
                                    writer.Write(file, 0, file.Length);
                                    fullLength += saveFileSize;
                                }
                                break;
                        }
                        //saveFile(receiveFile);
                    } catch(Exception e)
                    {
                        continue;
                    }
                }
            */
            }
            catch (Exception e) { }
        }
    }
}
