﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Diagnostics;
using System.Threading;
using System.IO;
using System.IO.Compression;
using System.Management;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections;
using StringTok;


namespace Server
{
    class TextHandler
    {
        private const int SEND_ID = 100;    // 필명 전송 상수
        private const int SEND_MSG = 200;   // 메시지 전송 상수
        private const int DISCONNECT = 300; // 연결 종료 상수
        private const int SEND_COUNT = 400; // 접속자 수 전송 상수

        public Thread th;

        private Server serverInfo;

        public Socket clientSocket;

        private List<TextHandler> clientList;

        private byte[] receiveData;

        private string str;
        private string id;
        private string temp;
        private int cnt;

        byte[] buf;

        public TextHandler(Socket clientSocket, Server serverInfo, List<TextHandler> clientList)
        {
            this.clientSocket = clientSocket;
            this.serverInfo = serverInfo;
            this.clientList = clientList;

            th = new Thread(new ThreadStart(run));
            th.Start();
        }

        private void run()
        {
            receiveData = new byte[256];

            while (th.IsAlive)
            {
                try
                {
                    int length = clientSocket.Receive(receiveData, receiveData.Length, SocketFlags.None);
                    str = Encoding.UTF8.GetString(receiveData, 0, length);
                    StringTokenizer st = new StringTokenizer(str, "||");
                    int part = int.Parse(st.NextToken());
                    buf = null;
                    switch (part)
                    {
                        case SEND_ID:

                            id = st.NextToken().Trim();
                            str = "연결되었습니다." + Environment.NewLine + "[ " + id + " ]님이 입장하셨습니다.";
                            temp = SEND_MSG + "||" + str + "||";
                            buf = Encoding.UTF8.GetBytes(temp);
                            SendMessage(buf);


                            ClientListSet();
                            SendMessage(buf);

                            Thread.Sleep(100);

                            // 받은 문자열 클라이언트로 재 전송
                            buf = Encoding.UTF8.GetBytes(str);
                            SendMessage(buf);

                            break;

                        case SEND_MSG:
                            temp = SEND_MSG + "||";
                            str = st.NextToken();
                            temp = temp + str + "||"; ;
                            
                            buf = Encoding.UTF8.GetBytes(temp);
                            SendMessage(buf);

                            break;

                        case DISCONNECT:

                            temp = st.NextToken();
                            str = "[ " + temp + " ]님이 접속을 종료 하였습니다.";
                            string str2 = SEND_MSG + "||[ " + temp + " ]님이 접속을 종료 하였습니다.";

                            foreach (TextHandler ch in clientList)
                            {
                                if (ch.id == temp)
                                {
                                    buf = Encoding.UTF8.GetBytes(str2);
                                    SendMessage(buf);

                                    clientList.Remove(ch);

                                    ClientListSet();
                                    SendMessage(buf);

                                    Thread.Sleep(100);
                                    
                                    ch.th.Abort();
                                    ch.clientSocket.Close();

                                    break;
                                }
                            }
                            break;
                    }

                }
                catch (Exception e)
                {

                }
            }
        }

        private void ClientListSet()
        {
            // 사용자 목록 (송신용)
            temp = SEND_ID + "||";

            cnt = 0;
            foreach (TextHandler ch2 in clientList)
            {
                temp = temp + ch2.id + Environment.NewLine;
                cnt++;
            }
            temp = temp + "||";
            buf = Encoding.UTF8.GetBytes(temp);
        }

        private void SendMessage(byte[] buf)
        {
            foreach (TextHandler ch in clientList)
            {
                ch.clientSocket.Send(buf);
            }
        }
        
    }
}
