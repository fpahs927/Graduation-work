﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Diagnostics;
using System.Threading;
using System.IO;
using System.IO.Compression;
using System.Management;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;

namespace Server
{
    class ScreenSocket
    {
        private IPAddress ip;               // IP 주소
        private int port;                   // Port 번호
        private IPEndPoint endPoint;        // 연결 매체

        private Socket socket;

        private Server serverInfo;          // 폼의 컨트롤 사용을 위함

        public List<ScreenHandler> clientList;

        public Thread th;

        // 화면 전송 소켓연결
        public ScreenSocket(Server formInfo)
        {
            this.serverInfo = formInfo;

            // 클라이언트 정보를 담을 list
            clientList = new List<ScreenHandler>();

            // 화면 전용 종단점 생성
            ip = IPAddress.Any;
            port = 22;
            endPoint = new IPEndPoint(ip, port);
            
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socket.Bind(endPoint);

            // 연결 대기
            socket.Listen(100);
            serverInfo.ScreenOP.Text = "waiting";

            th = new Thread(new ThreadStart(run));
            th.IsBackground = true;
            th.Start();
        }

        private void run()
        {
            while (th.IsAlive)
            {
                Socket clientSocket = socket.Accept();
                serverInfo.ScreenOP.Text = "acceptClient";

                if (clientList.Count == 0)
                {
                    ScreenHandler ch1 = new ScreenHandler(clientSocket, serverInfo, clientList);
                    clientList.Add(ch1);
                }
                else
                {
                    ScreenHandler ch2 = new ScreenHandler(clientSocket, serverInfo, clientList);
                    clientList.Add(ch2);
                }
            }
        }

        public void exit()
        {
            foreach (ScreenHandler ch in clientList)
            {
                ch.th.Abort();
                ch.clientSocket.Close();
            }
            
            //th.Interrupt();
            socket.Close();
        }
    }
}
