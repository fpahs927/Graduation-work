﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Diagnostics;
using System.Threading;
using System.IO;
using System.IO.Compression;
using System.Management;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using StringTok;


namespace Server
{
    class FileHandler
    {
        public Thread th;

        private Server serverInfo;

        public Socket clientSocket;

        private List<FileHandler> clientList;

        private byte[] receiveData;
        //private byte[] FileData;
        private int fileNamesize;
        private int filesize;

        public FileHandler(Server form)
        {
        }
        
        public FileHandler(Socket clientSocket, Server serverInfo, List<FileHandler> clientList)
        {
            this.clientSocket = clientSocket;
            this.serverInfo = serverInfo;
            this.clientList = clientList;

            th = new Thread(new ThreadStart(run));
            th.Start();
        }

        private void run()
        {
            while (th.IsAlive)
            {
                try
                {
                    receiveData = new byte[4];
                    clientSocket.Receive(receiveData, receiveData.Length, SocketFlags.None);
                    multiCast(receiveData);
                    filesize = BitConverter.ToInt32(receiveData, 0);

                    receiveData = new byte[4];
                    clientSocket.Receive(receiveData, receiveData.Length, SocketFlags.None);
                    multiCast(receiveData);
                    fileNamesize = BitConverter.ToInt32(receiveData, 0);
                    
                    receiveData = new byte[fileNamesize];
                    clientSocket.Receive(receiveData, receiveData.Length, SocketFlags.None);
                    multiCast(receiveData);

                    receiveData = new byte[1024];
                    int fullLength = 0;
                    while(fullLength < filesize)
                    {
                        int recevieLength = clientSocket.Receive(receiveData, receiveData.Length, SocketFlags.None);
                        multiCast(receiveData);
                        fullLength += recevieLength;
                    }
                }
                catch (Exception e)
                {
                    continue;
                }
            }
        }

        private void multiCast(byte[] buf)
        {
            foreach (FileHandler ch in clientList)
            {
                try
                {
                    ch.clientSocket.Send(buf);
                }
                catch (Exception e)
                {
                    continue;
                }
            }
        }
    }
}
