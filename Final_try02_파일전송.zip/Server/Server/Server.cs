﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server
{
    public partial class Server : Form
    {
        ScreenSocket ss;
        TextSocket ts;
        FileSocket fs;

        public Server()
        {
            InitializeComponent();
        }

        private void start_bnt_Click(object sender, EventArgs e)
        {
            start_bnt.Enabled = false;
            end_btn.Enabled = true;
            state_label.Text = "Server Open";
            ss = new ScreenSocket(this);
            ts = new TextSocket(this);
            fs = new FileSocket(this);
        }

        private void end_btn_Click(object sender, EventArgs e)
        {
            Notification_EXIT notify = new Notification_EXIT();
            notify.ShowDialog();

            ss.exit();
            ts.exit();
            fs.exit();

            this.Close();
        }
    }
}
