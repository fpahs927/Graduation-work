﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Diagnostics;
using System.Threading;
using System.IO;
using System.IO.Compression;
using System.Management;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using StringTools;
using System.Collections;
 

namespace Broadcaster
{
    public partial class Form1 : Form
    {
        private const int SEND_ID = 100;    // 필명 전송 상수
        private const int SEND_MSG = 200;   // 메시지 전송 상수
        private const int DISCONNECT = 300; // 연결 종료 상수
        private const int SEND_COUNT = 400; // 접속자 수 전송 상수

        private const int FILE_NAME = 1000;
        private const int FILE_SIZE = 2000;
        private const int FILE_DATA = 3000;

        // 이미지 전송부분 IP, Port, EndPoint, socket
        private IPAddress ip;
        private int port;
        private IPEndPoint endPoint;
        Socket socket;

        // 메시지 전송부분 IP(위에 선언되 IP변수 공유) Port, EndPoint, socket
        private int port2;               //
        private IPEndPoint endPoint2; //
        Socket socket2;                    //

        // 파일 전송부분
        private int port3;
        private IPEndPoint endPoint3;
        Socket socket3;

        // 이미지 소켓 연결 및 수신 스레드
        Thread th = null;

        // 메시지 소켓 연결 및 수신 스레드
        Thread th2 = null;

        // 파일 소켓 연결 및 수신 스레드
        Thread th3 = null;

        // 화면 캡쳐 스레드
        Thread th_Capture = null;

        private string id;
        private string str;
        private string list;
        private string cnt;         // 현재 접속 인원 수

        private byte[] receiveStr;          // 메시지 수신 변수
        private byte[] receiveData;         // 이미지 수신 변수
        private byte[] sendData;            // 전송할 이미지 변수
        private byte[] receiveFile;         // 파일 수신 변수
        private byte[] sendFile;            // 파일 송신 변수

        delegate void TextSetCallback();    // 채팅 입력을 처리할 Delegate
        delegate void ListSetCallback();
        delegate void Current_AccessCallback();

        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();    // Timer 선언

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        { //
            timer.Tick += new EventHandler(timer_Tick);     // Tick 이벤트 할당
            timer.Enabled = false;                          // 타이머 스위치 Off
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            // 타이머의 Tick 이벤트 발생 시 캡쳐 스레드 시작
            th_Capture = new Thread(new ThreadStart(capture_Screen));
            th_Capture.Start();
        }

        private void capture_Screen()
        {
            Size sz = new Size(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
            Bitmap bt = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
            Graphics g = Graphics.FromImage(bt);
            g.CopyFromScreen(0, 0, 0, 0, sz);

            //MemoryStream 방식 - MemoryStream 전송시 빠름
            MemoryStream ms = new MemoryStream();
            ms.Position = 0;
            bt.Save(ms, ImageFormat.Jpeg);              // 화면 캡쳐
            sendData = ms.ToArray();                    // Byte[]로 변환

            try
            {
                socket.Send(sendData);                  // 이미지 전송
                //lbl.Text = "화면 전송중";
            }
            catch (Exception e)
            {

            }
        }

        private void button1_Click(object sender, EventArgs e) //btnsend 
        {
            string str = SEND_MSG + "||" + id + ">> " + textBox1.Text + "||";
            byte[] strBuffer = Encoding.UTF8.GetBytes(str);
            socket2.Send(strBuffer);
            textBox1.Text = "";

        }

        // 이미지 전용 소켓 연결 함수
        private void Connect_Host()
        {
            //lbl.Text = "연결시작";
            try
            {
                socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                socket.Connect(endPoint);
                //lbl.Text = "연결 성공";

                receiveData = new byte[300000];
                while (th.IsAlive)  // 이미지 전용 스레드가 작동하고 있을경우 반복
                {
                    try
                    {
                        socket.Receive(receiveData, receiveData.Length, SocketFlags.None);
                        //multiCast(receiveData);
                        //clientSocket.Send(receiveData);

                       // byte[] PicData = zip.Decompress(receiveData);
                          byte[] PicData = receiveData;
                        //받은 데이터 출력
                        print_Screen(PicData);
                    }
                    catch (Exception e)
                    {
                        continue;   // 수신을 실패 하더라도 계속 수신 시도
                    }
                }
            }
            catch (Exception e)
            {
            }
        }
        private void print_Screen(byte[] PicData)
        {
            MemoryStream ms = new MemoryStream();
            ms.Write(PicData, 0, PicData.Length);
            Bitmap bitmap = new Bitmap(ms);
            bitmap.Save("x2.jpg", ImageFormat.Jpeg);
            pictureBox1.ImageLocation = "x2.jpg";
        }

        private void EXIT_Click(object sender, EventArgs e)
        {
            try
            {
                //sendDisConnect();
                Thread.Sleep(500);

                //socket.Shutdown(SocketShutdown.Both);
                socket.Close();
                //socket2.Shutdown(SocketShutdown.Both);
                socket2.Close();
                socket3.Close();
                th2.Abort();
                th.Abort();
                th3.Abort();
            }
            catch (Exception exc) { }
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            timer.Tick += new EventHandler(timer_Tick);     // Tick 이벤트 할당
            timer.Enabled = false;                          // 타이머 스위치 Off
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                sendDisConnect();
                Thread.Sleep(500);

                //socket.Shutdown(SocketShutdown.Both);
                socket.Close();
                //socket2.Shutdown(SocketShutdown.Both);
                socket2.Close();
                socket3.Close();
                th2.Abort();
                th.Abort();
                th3.Abort();
                this.Close();
            }
            catch (Exception exc) { }
        }

        private void START_Click(object sender, EventArgs e)
        {
            START.Enabled = false;
            START.Visible = false;
            EXIT.Enabled = true;
            EXIT.Visible = true;
            SEND.Enabled = true;

            textBox1.ReadOnly = false; //txtinput 
            textBox1.Focus();

            // 이미지를 전송할 서버측 IP 주소 , Port 번호 설정
            ip = IPAddress.Parse("127.0.0.1");
            port = 22;
            endPoint = new IPEndPoint(ip, port);
            // 이미지 전용 소켓 스레드
            th = new Thread(new ThreadStart(Connect_Host));
            th.Start();

            // 메시지를 전송할 서버측 IP 주소(위 내용 공유), Port 번호 설정
            port2 = 23;
            endPoint2 = new IPEndPoint(ip, port2);
            // 메시지 전용 소켓 스레드
            th2 = new Thread(new ThreadStart(Connect_Host2));
            th2.Start();

            port3 = 24;
            endPoint3 = new IPEndPoint(ip, port3);
            th3 = new Thread(new ThreadStart(Connect_Host3));
            th3.Start();

            // 타이머를 사용하여 Interval 간격으로 캡쳐 수행
            timer.Interval = 300;   // interval 설정(캡쳐 간격)
            timer.Enabled = true;   // 타이머 스위치 On
        }

       // 메시지 전용 소켓 연결 함수
         private void Connect_Host2()
         {
             //lbl.Text = "연결시작";
             try
             {
                 socket2 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                 socket2.Connect(endPoint2);
                 //lbl.Text = "연결 성공";

                 //sendID();

                 receiveStr = new byte[256];
                 while (th2.IsAlive) // 메시지 전용 스레드가 작동하고 있을경우 반복
                 {
                     try
                     {
                         int length = socket2.Receive(receiveStr, receiveStr.Length, SocketFlags.None);
                         str = Encoding.UTF8.GetString(receiveStr, 0, length);
                         StringTokenizer st = new StringTokenizer(str, "||");
                         int part = int.Parse(st.nextToken());

                         switch (part)
                         {
                             case SEND_ID:

                                 list = "";
                                 list = st.nextToken();
                                 ListSet();

                                 break;

                             case SEND_MSG:

                                 str = st.nextToken();
                                 TextSet();

                                 break;

                             case SEND_COUNT:
                                 cnt = st.nextToken();
                                // Current_Access();

                                 break;
                         }

                     }
                     catch (Exception e)
                     {
                         continue;
                     }
                 }

             }
             catch (Exception e)
             {
             }
         }

        private void TextSet()
        {
            if (this.textBox2.InvokeRequired)  //textoutput 
            {
                TextSetCallback d = new TextSetCallback(TextSet);
                this.Invoke(d, new object[] { });
            }
            else
            {
                this.textBox2.AppendText(str + Environment.NewLine);
            }
        }

        private void ListSet()
        {
            if (textBox3.InvokeRequired) //txtlist 
            {
                ListSetCallback d = new ListSetCallback(ListSet);
                Invoke(d, new object[] { });
            }
            else
            {
                textBox3.Text = "";

                textBox3.Text = list;
            }
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                e.KeyChar = ' ';
                string str = SEND_MSG + "||" + id + ">>" + textBox1.Text + "||";
                byte[] strBuffer = Encoding.UTF8.GetBytes(str);
                socket2.Send(strBuffer);
                textBox1.Text = "";
            }
        }
        private void sendID()
        {
            id = textBox1.Text;
            string str = SEND_ID + "||" + id + "||";
            byte[] strBuffer = Encoding.UTF8.GetBytes(str);
            socket2.Send(strBuffer);    // 필명 전송      
        }
        private void sendDisConnect()
        {
            string str = DISCONNECT + "||" + id + "||";
            byte[] strBuffer = Encoding.UTF8.GetBytes(str);
            socket2.Send(strBuffer);    // 메시지 전송
        }

        private void Connect_Host3()
        {
            try
            {
                socket3 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                socket3.Connect(endPoint3);

                receiveFile = new byte[5000000];
                while (th3.IsAlive)
                {
                    try
                    {
                        socket3.Receive(receiveFile, receiveFile.Length, SocketFlags.None);
                    } catch(Exception e)
                    {
                        continue;
                    }
                }
            }
            catch (Exception e) { }
        }

        string filename = "";
        private void FileButton_Click(object sender, EventArgs e)
        {
            try
            {
                string filePath;
                OpenFileDialog open = new OpenFileDialog();
                open.Filter = "모든파일(All File)|*.*";
                if (DialogResult.OK == open.ShowDialog())
                {
                    filePath = open.FileName;
                } else return;

                string[] f = filePath.Split('\\');
                filename = f[f.Count() - 1];

                FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);

                int fileSize = (int)fs.Length;
                byte[] fileBuffer = BitConverter.GetBytes(fileSize);
                socket3.Send(fileBuffer);
                
                int fileNameSize = Encoding.UTF8.GetByteCount(filename);
                fileBuffer = BitConverter.GetBytes(fileNameSize);
                socket3.Send(fileBuffer);

                fileBuffer = Encoding.UTF8.GetBytes(filename);
                socket3.Send(fileBuffer);

                int count = fileSize / 1024 + 1;
                BinaryReader br = new BinaryReader(fs);

                for(int i = 0; i < count; i++)
                {
                    fileBuffer = br.ReadBytes(1024);
                    socket3.Send(fileBuffer);
                }
                br.Close();
                fs.Close();
            } catch(Exception)
            {
                return;
            }

            /*
            // 파일 오픈
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "모든파일(All File)|*.*";
            if (DialogResult.OK == open.ShowDialog())
            {
                filename = open.FileName;
            }
            else return;

            // 파일 이름 전송
            sendFileName(filename);

            // 파일 크기 전송
            FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.Read);
            int fileLength = (int)fs.Length;
            sendFileSize(fileLength);

            // 파일 전송
            BinaryReader br = new BinaryReader(fs);
            int count = fileLength / 1024 + 1;
            for(int i = 0; i < count; i++)
            {
                sendFile = br.ReadBytes(1024);

                socket3.Send(sendFile);
            }

            br.Close();
            fs.Close();
            //*/
        }

        private void sendFileName(string s)
        {
            string[] name = s.Split('\\');
            string realName = name[name.Count() - 1];
            int length = realName.Length;

            // 파일 이름 전송
            string sendData = FILE_NAME + "||" + realName + "||";
            byte[] fileS = Encoding.UTF8.GetBytes(sendData);
            socket3.Send(fileS);
        }

        // 파일 크기 전송
        private void sendFileSize(int i)
        {
            string s = FILE_SIZE + "||" + i + "||";
            byte[] fileS = Encoding.UTF8.GetBytes(s);
            socket3.Send(fileS);
        }
    }
}
